export type BlockSectionMessages = {
  collapse: string;
  expand: string;
};
